public class Output {
    private String success;
    
    public String getSuccess() {
        return success;
    }
}
