/**
 * Created by yeowleong on 16/5/14.
 */
public class Product {
    private String name;
    private double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    
}
