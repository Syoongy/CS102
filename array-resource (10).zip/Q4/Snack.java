/**
 * Created by yeowleong on 16/5/14.
 */
public class Snack {
    
	
}
