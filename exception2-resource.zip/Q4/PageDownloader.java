import java.net.URL;
import java.util.Scanner;

public class PageDownloader {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);

        System.out.print("Enter the URL> ");
        String websiteURL = console.nextLine();

        URL url = new URL(websiteURL);

        Scanner sc = new Scanner(url.openStream());

        while (sc.hasNext()) {
            System.out.println(sc.nextLine());
        }
    }
}
