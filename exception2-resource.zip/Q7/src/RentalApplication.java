// Main class - run this!

public class RentalApplication {
    public static void main(String[] args) {
        RentalMenu menu = new RentalMenu();
        menu.start();
    }
}
