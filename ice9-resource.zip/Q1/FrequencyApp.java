public class FrequencyApp {

}