import java.util.Random;

public class Minesweeper {

    public static void main(String[] args) {
       Minesweeper minesweeper = new Minesweeper(4,6,2);
        System.out.println(minesweeper.toString());
    }
}
